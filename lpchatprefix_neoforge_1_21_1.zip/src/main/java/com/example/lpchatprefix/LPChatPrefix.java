package com.example.lpchatprefix;

import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.ServerChatEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;
import net.minecraft.server.level.ServerPlayer;

import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.user.User;
import net.luckperms.api.cacheddata.CachedMetaData;

import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

@Mod(LPChatPrefix.MOD_ID)
public class LPChatPrefix {
    public static final String MOD_ID = "lpchatprefix";

    private final MiniMessage mini = MiniMessage.miniMessage();
    private final LegacyComponentSerializer legacy = LegacyComponentSerializer.legacySection();

    public LPChatPrefix() {
        net.neoforged.neoforge.common.MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onChat(ServerChatEvent event) {
        ServerPlayer player = event.getPlayer();

        LuckPerms luckPerms;
        try {
            luckPerms = LuckPermsProvider.get();
        } catch (IllegalStateException e) {
            return;
        }

        User user = luckPerms.getUserManager().getUser(player.getUUID());
        if (user == null) return;

        CachedMetaData meta = user.getCachedData().getMetaData();

        String prefix = meta.getPrefix();
        String suffix = meta.getSuffix();

        if (prefix == null) prefix = "";
        if (suffix == null) suffix = "";

        prefix = prefix.replaceAll("&", "§");
        suffix = suffix.replaceAll("&", "§");

        Component prefixComp = parseComponent(prefix);
        Component suffixComp = parseComponent(suffix);
        Component message = parseComponent("<gray>" + event.getRawText() + "</gray>");

        Component finalMsg = Component.empty()
                .append(prefixComp)
                .append(Component.literal(player.getName().getString()).withStyle(ChatFormatting.WHITE))
                .append(suffixComp)
                .append(Component.literal(": "))
                .append(message);

        event.setComponent(finalMsg);
    }

    private Component parseComponent(String input) {
        if (input == null || input.isEmpty()) return Component.empty();
        try {
            return (Component) (Object) mini.deserialize(input);
        } catch (Exception e) {
            return (Component) (Object) legacy.deserialize(input);
        }
    }
}
